package com.example.bookstore.dto;

public class CustomerDTO {
    @NotNull
    @Size(min = 1, max = 50)
    private String firstName;

    @NotNull
    @Size(min = 1, max = 50)
    private String lastName;

    @NotNull
    @Email
    private String email;

    @NotNull
    @Size(min = 10, max = 20)
    private String phoneNumber;

    // getters and setters
}
