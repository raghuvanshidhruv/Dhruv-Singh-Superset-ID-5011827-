package com.example.bookstore.config;

//com.example.bookstore.config.CorsConfig.java
@Configuration
public class CorsConfig {
@Bean
public CorsFilter corsFilter() {
 UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
 CorsConfiguration config = new CorsConfiguration();
 config.setAllowCredentials(true);
 config.addAllowedOrigin("*");
 config.addAllowedHeader("*");
 config.addAllowedMethod("*");
 source.registerCorsConfiguration("/**", config);
 return new CorsFilter(source);
}
}