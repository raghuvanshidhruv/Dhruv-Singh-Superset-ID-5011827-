package com.library.LibraryManagement.controller;

@RestController
@RequestMapping("/customers")
public class CustomerController {

    @PostMapping
    public ResponseEntity<Customer> createCustomer(@RequestBody Customer customer) {
        // TO DO: implement logic to create a new customer
        customer.setId(1L);
        return new ResponseEntity<>(customer, HttpStatus.CREATED);
    }

    @PostMapping("/register")
    public ResponseEntity<String> registerCustomer(@RequestParam String name, @RequestParam String email, @RequestParam String phone) {
        // TO DO: implement logic to register a new customer
        return new ResponseEntity<>("Customer registered successfully!", HttpStatus.OK);
    }
}