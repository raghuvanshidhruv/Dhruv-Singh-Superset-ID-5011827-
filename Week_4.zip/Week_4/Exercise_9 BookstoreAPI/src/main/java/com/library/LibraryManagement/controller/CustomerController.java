package com.library.LibraryManagement.controller;

@RestController
@RequestMapping("/api/customers")
public class CustomerController {
    @Autowired
    private CustomerService customerService;

    @PostMapping
    public ResponseEntity<CustomerResource> createCustomer(@RequestBody CustomerDTO customerDTO) {
        CustomerResource resource = customerService.createCustomer(customerDTO);
        return ResponseEntity.created(URI.create("/api/customers/" + resource.getCustomer().getId())).body(resource);
    }

    @GetMapping
    public ResponseEntity<List<CustomerResource>> getAllCustomers() {
        List<CustomerResource> resources = customerService.getAllCustomers();
        return ResponseEntity.ok(resources);
    }

    @GetMapping("/{id}")
    public ResponseEntity<CustomerResource> getCustomer(@PathVariable Long id) {
        CustomerResource resource = customerService.getCustomer(id);
        return ResponseEntity.ok(resource);
    }

    // ...
}