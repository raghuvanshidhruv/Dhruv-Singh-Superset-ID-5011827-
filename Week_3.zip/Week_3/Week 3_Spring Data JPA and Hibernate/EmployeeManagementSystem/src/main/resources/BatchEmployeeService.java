@Service
public class BatchEmployeeService {
    
    @Autowired
    private SessionFactory sessionFactory;
    
    @Transactional
    public void batchSaveEmployees(List<Employee> employees) {
        Session session = sessionFactory.getCurrentSession();
        int batchSize = 20;
        for (int i = 0; i < employees.size(); i++) {
            session.save(employees.get(i));
            if (i % batchSize == 0) {
                session.flush();
                session.clear();
            }
        }
        session.flush();
        session.clear();
    }
}