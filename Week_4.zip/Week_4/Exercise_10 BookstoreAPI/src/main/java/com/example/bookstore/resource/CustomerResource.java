package com.example.bookstore.resource;

public class CustomerResource extends ResourceSupport {
    private Customer customer;

    public CustomerResource(Customer customer) {
        this.customer = customer;
    }

    public Customer getCustomer() {
        return customer;
    }
}
