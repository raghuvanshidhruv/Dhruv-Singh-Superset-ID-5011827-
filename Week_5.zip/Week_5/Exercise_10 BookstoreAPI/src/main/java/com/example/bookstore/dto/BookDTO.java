package com.example.bookstore.dto;

public class BookDTO {
    @NotNull
    @Size(min = 1, max = 100)
    private String title;

    @NotNull
    @Size(min = 1, max = 100)
    private String author;

    @Min(1900)
    private int publicationYear;

    @NotNull
    private double price;

    // getters and setters
}
