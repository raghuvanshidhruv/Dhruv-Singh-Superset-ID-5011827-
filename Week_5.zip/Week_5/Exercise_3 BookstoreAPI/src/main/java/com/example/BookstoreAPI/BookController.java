package com.example.BookstoreAPI;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("/books")
public class BookController {
	
	@GetMapping("/{id}")
	public ResponseEntity<Book> getBookById(@PathVariable Long id) {
	    // TO DO: implement logic to retrieve a book by ID
	    Book book = new Book(id, "Book " + id, "Author " + id, 10.99, "1234567890");
	    return new ResponseEntity<>(book, HttpStatus.OK);
	}
	
	@GetMapping
	public ResponseEntity<List<Book>> getBooksByTitleAndAuthor(
	        @RequestParam(required = false) String title,
	        @RequestParam(required = false) String author) {
	    // TO DO: implement logic to filter books by title and author
	    List<Book> books = new ArrayList<>();
	    if (title != null && author != null) {
	        books.add(new Book(1L, title, author, 10.99, "1234567890"));
	    } else if (title != null) {
	        books.add(new Book(1L, title, "Author 1", 10.99, "1234567890"));
	    } else if (author != null) {
	        books.add(new Book(1L, "Book 1", author, 10.99, "1234567890"));
	    } else {
	        books.add(new Book(1L, "Book 1", "Author 1", 10.99, "1234567890"));
	        books.add(new Book(2L, "Book 2", "Author 2", 9.99, "2345678901"));
	    }
	    return new ResponseEntity<>(books, HttpStatus.OK);
	}

    @GetMapping
    public ResponseEntity<List<Book>> getAllBooks() {
        List<Book> books = Arrays.asList(
                new Book(1L, "Book 1", "Author 1", 10.99, "1234567890"),
                new Book(2L, "Book 2", "Author 2", 9.99, "2345678901")
        );
        return new ResponseEntity<>(books, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Book> getBookById(@PathVariable Long id) {
        Book book = new Book(id, "Book " + id, "Author " + id, 10.99, "1234567890");
        return new ResponseEntity<>(book, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<Book> createBook(@RequestBody Book book) {
        // Create a new book
        return new ResponseEntity<>(book, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Book> updateBook(@PathVariable Long id, @RequestBody Book book) {
        // Update an existing book
        return new ResponseEntity<>(book, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBook(@PathVariable Long id) {
        // Delete a book by ID
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}