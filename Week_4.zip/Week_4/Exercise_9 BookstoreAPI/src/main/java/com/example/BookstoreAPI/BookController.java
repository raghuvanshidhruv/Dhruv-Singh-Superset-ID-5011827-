package com.example.BookstoreAPI;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("/api/books")
public class BookController {
    @Autowired
    private BookService bookService;

    @PostMapping
    public ResponseEntity<BookResource> createBook(@RequestBody BookDTO bookDTO) {
        BookResource resource = bookService.createBook(bookDTO);
        return ResponseEntity.created(URI.create("/api/books/" + resource.getBook().getId())).body(resource);
    }

    @GetMapping
    public ResponseEntity<List<BookResource>> getAllBooks() {
        List<BookResource> resources = bookService.getAllBooks();
        return ResponseEntity.ok(resources);
    }

    @GetMapping("/{id}")
    public ResponseEntity<BookResource> getBook(@PathVariable Long id) {
        BookResource resource = bookService.getBook(id);
        return ResponseEntity.ok(resource);
    }

    // ...
}