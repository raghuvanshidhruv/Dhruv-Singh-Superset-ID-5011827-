package com.example.bookstore.security.filter;

public class JwtAuthenticationFilter extends OncePerRequestFilter {
	  // ...
	}
