public interface SecondaryEmployeeRepository extends JpaRepository<Employee, Long> {
    
    @EntityGraph(attributePaths = "department")
    List<EmployeeSummary> findAllBy();
    
    @EntityGraph(attributePaths = "department")
    List<EmployeeDetails> findAllByDepartmentName(String departmentName);
    
    @Qualifier("secondaryDataSource")
    @Bean
    public JdbcTemplate secondaryJdbcTemplate() {
        return new JdbcTemplate(secondaryDataSource());
    }
}