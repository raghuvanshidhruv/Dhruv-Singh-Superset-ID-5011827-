package com.example.bookstore.integration;

//com.example.bookstore.integration.BookstoreIntegrationTests.java
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class BookstoreIntegrationTests {
// ...
}
