package com.example.bookstore.security.service;

public interface UserDetailsService {
	  // ...
	}

	// com.example.bookstore.security.service.UserDetailsServiceImpl.java
	@Service
	public class UserDetailsServiceImpl implements UserDetailsService {
	  // ...
	}
