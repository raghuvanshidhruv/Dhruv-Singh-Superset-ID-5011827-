package com.library.LibraryManagement.controller;

@RestController
@RequestMapping("/api/customers")
public class CustomerController {
    @Autowired
    private CustomerService customerService;

    @GetMapping(produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<List<CustomerResource>> getAllCustomers(@RequestHeader("Accept") String acceptHeader) {
        List<CustomerResource> resources = customerService.getAllCustomers();
        if (acceptHeader.contains(MediaType.APPLICATION_JSON_VALUE)) {
            return ResponseEntity.ok(resources);
        } else if (acceptHeader.contains(MediaType.APPLICATION_XML_VALUE)) {
            return ResponseEntity.ok(resources, MediaType.APPLICATION_XML);
        } else {
            throw new UnsupportedMediaTypeException("Unsupported media type");
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<CustomerResource> getCustomer(@PathVariable Long id, @RequestHeader("Accept") String acceptHeader) {
        CustomerResource resource = customerService.getCustomer(id);
        if (acceptHeader.contains(MediaType.APPLICATION_JSON_VALUE)) {
            return ResponseEntity.ok(resource);
        } else if (acceptHeader.contains(MediaType.APPLICATION_XML_VALUE)) {
            return ResponseEntity.ok(resource, MediaType.APPLICATION_XML);
        } else {
            throw new UnsupportedMediaTypeException("Unsupported media type");
        }
    }

    // ...
}