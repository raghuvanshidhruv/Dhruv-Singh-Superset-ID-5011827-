package com.example.bookstore.metrics;

@Component
public class BookstoreMetrics {
    @Autowired
    private BookService bookService;

    @Bean
    public MeterRegistryCustomizer meterRegistryCustomizer(MeterRegistry registry) {
        return registryConfig -> {
            registry.gauge("bookstore.books.count", Tags.empty(), bookService.getCount());
        };
    }
}
