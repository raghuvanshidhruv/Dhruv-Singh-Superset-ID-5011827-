package com.example.bookstore.controller;

//com.example.bookstore.controller.BookControllerTest.java
@RunWith(SpringRunner.class)
@WebMvcTest(BookController.class)
public class BookControllerTest {
@Autowired
private MockMvc mockMvc;

@MockBean
private BookService bookService;

// ...
}
