@Service
public class EmployeeService {
    
    @Autowired
    private BatchEmployeeService batchEmployeeService;
    
    public void saveEmployees(List<Employee> employees) {
        batchEmployeeService.batchSaveEmployees(employees);
    }
}