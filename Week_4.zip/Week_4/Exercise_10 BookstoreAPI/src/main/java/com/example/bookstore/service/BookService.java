package com.example.bookstore.service;

@Service
public class BookService {
    // ...

    public BookResource createBook(BookDTO bookDTO) {
        Book book = new Book();
        // ...
        return new BookResource(bookRepository.save(book));
    }

    public List<BookResource> getAllBooks() {
        List<Book> books = bookRepository.findAll();
        List<BookResource> resources = new ArrayList<>();
        for (Book book : books) {
            resources.add(new BookResource(book));
        }
        return resources;
    }

    public BookResource getBook(Long id) {
        Book book = bookRepository.findById(id).orElse(null);
        if (book == null) {
            throw new NotFoundException("Book not found");
        }
        return new BookResource(book);
    }

    // ...
}
