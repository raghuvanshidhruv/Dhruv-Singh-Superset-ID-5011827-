package com.example.bookstore.repository;

//com.example.bookstore.repository.BookRepositoryIntegrationTests.java
@RunWith(SpringRunner.class)
@DataJpaTest
public class BookRepositoryIntegrationTests {
@Autowired
private BookRepository bookRepository;

@Test
public void testFindAllBooks() {
 List<Book> books = bookRepository.findAll();
 assertThat(books, hasSize(2));
}
}
