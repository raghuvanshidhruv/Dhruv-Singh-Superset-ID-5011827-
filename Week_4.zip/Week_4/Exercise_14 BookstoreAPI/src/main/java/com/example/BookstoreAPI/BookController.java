package com.example.BookstoreAPI;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("/api/books")
public class BookController {
	
	@Test
	public void testGetBooks() throws Exception {
	  MvcResult result = mockMvc.perform(get("/api/books"))
	    .andExpect(status().isOk())
	    .andReturn();
	  
	  String responseBody = result.getModelAndView().getModel().toString();
	  assertThat(responseBody, containsString("Book 1"));
	  assertThat(responseBody, containsString("Book 2"));
	}
	
    @Autowired
    private BookService bookService;

    @GetMapping(produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<List<BookResource>> getAllBooks(@RequestHeader("Accept") String acceptHeader) {
        List<BookResource> resources = bookService.getAllBooks();
        if (acceptHeader.contains(MediaType.APPLICATION_JSON_VALUE)) {
            return ResponseEntity.ok(resources);
        } else if (acceptHeader.contains(MediaType.APPLICATION_XML_VALUE)) {
            return ResponseEntity.ok(resources, MediaType.APPLICATION_XML);
        } else {
            throw new UnsupportedMediaTypeException("Unsupported media type");
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<BookResource> getBook(@PathVariable Long id, @RequestHeader("Accept") String acceptHeader) {
        BookResource resource = bookService.getBook(id);
        if (acceptHeader.contains(MediaType.APPLICATION_JSON_VALUE)) {
            return ResponseEntity.ok(resource);
        } else if (acceptHeader.contains(MediaType.APPLICATION_XML_VALUE)) {
            return ResponseEntity.ok(resource, MediaType.APPLICATION_XML);
        } else {
            throw new UnsupportedMediaTypeException("Unsupported media type");
        }
    }

    // ...
}