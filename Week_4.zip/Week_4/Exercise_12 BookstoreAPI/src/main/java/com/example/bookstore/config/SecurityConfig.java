package com.example.bookstore.config;

//com.example.bookstore.config.SecurityConfig.java
//com.example.bookstore.config.SecurityConfig.java
@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {
// ...

@Override
protected void configure(HttpSecurity http) throws Exception {
 http.csrf().disable()
   .authorizeRequests()
   .antMatchers("/api/authenticate").permitAll()
   .anyRequest().authenticated()
   .and()
   .addFilter(new JwtAuthenticationFilter(authenticationManager(), jwtTokenUtil))
   .addFilter(corsFilter());
}

@Bean
public CorsFilter corsFilter() {
 return new CorsConfig().corsFilter();
}
}
