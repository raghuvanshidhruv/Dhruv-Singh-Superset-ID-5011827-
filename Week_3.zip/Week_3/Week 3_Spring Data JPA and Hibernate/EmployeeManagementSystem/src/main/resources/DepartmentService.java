@Service
public class DepartmentService {
    @Autowired
    private DepartmentRepository departmentRepository;

    public List<DepartmentSummary> getAllDepartments() {
        return departmentRepository.findAllBy();
    }

    public List<DepartmentDetails> getDepartmentsByEmployeeCountGreaterThan(Long employeeCount) {
        return departmentRepository.findAllByEmployeeCountGreaterThan(employeeCount);
    }
}