package com.example.bookstore.service;

@Service
public class BookService {
    @Autowired
    private BookRepository bookRepository;

    public Book createBook(BookDTO bookDTO) {
        Book book = new Book();
        book.setTitle(bookDTO.getTitle());
        book.setAuthor(bookDTO.getAuthor());
        book.setPublicationYear(bookDTO.getPublicationYear());
        book.setPrice(bookDTO.getPrice());
        return bookRepository.save(book);
    }

    public List<Book> getAllBooks() {
        return bookRepository.findAll();
    }

    public Book getBook(Long id) {
        return bookRepository.findById(id).orElse(null);
    }

    public Book updateBook(Long id, BookDTO bookDTO) {
        Book book = getBook(id);
        if (book == null) {
            throw new NotFoundException("Book not found");
        }
        if (book.getVersion() != bookDTO.getVersion()) {
            throw new OptimisticLockException("Book has been modified by another user");
        }
        book.setTitle(bookDTO.getTitle());
        book.setAuthor(bookDTO.getAuthor());
        book.setPublicationYear(bookDTO.getPublicationYear());
        book.setPrice(bookDTO.getPrice());
        return bookRepository.save(book);
    }

    public void deleteBook(Long id) {
        Book book = getBook(id);
        if (book == null) {
            throw new NotFoundException("Book not found");
        }
        bookRepository.delete(book);
    }
}
