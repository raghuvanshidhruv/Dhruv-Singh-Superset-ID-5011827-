package com.example.employee.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.employee.entity.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    
    @EntityGraph(attributePaths = "department")
    List<EmployeeSummary> findAllBy();
    
    @EntityGraph(attributePaths = "department")
    List<EmployeeDetails> findAllByDepartmentName(String departmentName);
    
    @Qualifier("primaryDataSource")
    @Bean
    public JdbcTemplate primaryJdbcTemplate() {
        return new JdbcTemplate(primaryDataSource());
    }
}