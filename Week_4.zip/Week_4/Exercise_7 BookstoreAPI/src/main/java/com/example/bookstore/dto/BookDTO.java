package com.example.bookstore.dto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class BookDTO {
    @JsonProperty("id")
    private Long id;

    @JsonProperty("title")
    private String title;

    @JsonProperty("author")
    private String author;

    @JsonProperty("publication_year")
    private int publicationYear;

    @JsonProperty("price")
    private double price;

    // getters and setters
}
