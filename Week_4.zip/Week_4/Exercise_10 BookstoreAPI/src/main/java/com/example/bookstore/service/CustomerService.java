package com.example.bookstore.service;

@Service
public class CustomerService {
    // ...

    public CustomerResource createCustomer(CustomerDTO customerDTO) {
        Customer customer = new Customer();
        // ...
        return new CustomerResource(customerRepository.save(customer));
    }

    public List<CustomerResource> getAllCustomers() {
        List<Customer> customers = customerRepository.findAll();
        List<CustomerResource> resources = new ArrayList<>();
        for (Customer customer : customers) {
            resources.add(new CustomerResource(customer));
        }
        return resources;
    }

    public CustomerResource getCustomer(Long id) {
        Customer customer = customerRepository.findById(id).orElse(null);
        if (customer == null) {
            throw new NotFoundException("Customer not found");
        }
        return new CustomerResource(customer);
    }

    // ...
}
