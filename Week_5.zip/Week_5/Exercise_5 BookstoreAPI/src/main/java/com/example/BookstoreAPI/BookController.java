package com.example.BookstoreAPI;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("/books")
public class BookController {

    @GetMapping
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<List<Book>> getAllBooks() {
        List<Book> books = // retrieve books from database or service
        return new ResponseEntity<>(books, getCustomHeaders(), HttpStatus.OK);
    }

    @GetMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<Book> getBookById(@PathVariable Long id) {
        Book book = // retrieve book by id from database or service
        return new ResponseEntity<>(book, getCustomHeaders(), HttpStatus.OK);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<Book> createBook(@RequestBody Book book) {
        // create book in database or service
        return new ResponseEntity<>(book, getCustomHeaders(), HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<Book> updateBook(@PathVariable Long id, @RequestBody Book book) {
        // update book in database or service
        return new ResponseEntity<>(book, getCustomHeaders(), HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public ResponseEntity<Void> deleteBook(@PathVariable Long id) {
        // delete book from database or service
        return new ResponseEntity<>(getCustomHeaders(), HttpStatus.NO_CONTENT);
    }

    private HttpHeaders getCustomHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.add("X-Custom-Header", "Book Management API");
        headers.add("X-Response-Time", String.valueOf(System.currentTimeMillis()));
        return headers;
    }
}