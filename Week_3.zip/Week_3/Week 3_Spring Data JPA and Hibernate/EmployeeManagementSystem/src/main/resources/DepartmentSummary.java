public interface DepartmentSummary {
    Long getId();
    String getName();
}