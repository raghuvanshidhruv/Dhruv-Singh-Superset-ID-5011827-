package com.example.BookstoreAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookstoreApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
