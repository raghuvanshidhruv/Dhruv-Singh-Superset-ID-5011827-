package com.example.bookstore.resource;

public class BookResource extends ResourceSupport {
    private Book book;

    public BookResource(Book book) {
        this.book = book;
    }

    public Book getBook() {
        return book;
    }
}
