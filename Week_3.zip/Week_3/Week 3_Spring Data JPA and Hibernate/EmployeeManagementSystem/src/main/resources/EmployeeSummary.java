public interface EmployeeSummary {
    Long getId();
    String getName();
    String getEmail();
}