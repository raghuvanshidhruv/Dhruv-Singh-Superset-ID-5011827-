package com.example.BookstoreAPI;

//com.example.bookstore.BookstoreApplicationTests.java
@RunWith(SpringRunner.class)
@SpringBootTest
public class BookstoreApplicationTests {
// ...
}
